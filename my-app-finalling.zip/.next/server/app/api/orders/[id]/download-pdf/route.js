"use strict";(()=>{var e={};e.id=2193,e.ids=[2193],e.modules={3524:e=>{e.exports=require("@prisma/client")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},8018:e=>{e.exports=require("puppeteer")},9603:(e,t,i)=>{i.r(t),i.d(t,{originalPathname:()=>b,patchFetch:()=>y,requestAsyncStorage:()=>u,routeModule:()=>v,serverHooks:()=>g,staticGenerationAsyncStorage:()=>f});var a={};i.r(a),i.d(a,{GET:()=>m});var o=i(9303),n=i(8716),s=i(670),d=i(7070),r=i(2331),l=i(8018),c=i.n(l),p=i(1838);async function m(e,{params:t}){try{var i;let{id:e}=t,a=await r._.order.findUnique({where:{id:e},include:{client:!0,payments:{orderBy:{paymentNumber:"asc"}}}});if(!a)return d.NextResponse.json({message:"Order not found"},{status:404});let o=(e=>{if(Array.isArray(e))return e;if("string"==typeof e)try{let t=JSON.parse(e);return Array.isArray(t)?t:[]}catch{}return[]})(a.items),n=((i=a.dressPhotos)&&Array.isArray(i)?i.filter(e=>"string"==typeof e):null)||[],s=e=>`Rp ${parseFloat(e.toString()).toLocaleString("id-ID")}`,l=`
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Order Details - ${a.orderNumber}</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Arial', sans-serif;
                line-height: 1.6;
                color: #333;
                background: #f9f9f9;
                padding: 20px;
            }
            
            .container {
                max-width: 800px;
                margin: 0 auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);
            }
            
            .header {
                text-align: center;
                margin-bottom: 30px;
                border-bottom: 3px solid #d4b896;
                padding-bottom: 20px;
            }
            
            .header h1 {
                color: #d4b896;
                font-size: 28px;
                margin-bottom: 10px;
            }
            
            .header p {
                color: #666;
                font-size: 14px;
            }
            
            .section {
                margin-bottom: 25px;
                padding: 20px;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                background: #fafafa;
            }
            
            .section h2 {
                color: #d4b896;
                font-size: 18px;
                margin-bottom: 15px;
                border-bottom: 2px solid #d4b896;
                padding-bottom: 5px;
            }
            
            .info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
            }
            
            .info-item {
                margin-bottom: 10px;
            }
            
            .info-label {
                font-weight: bold;
                color: #555;
                font-size: 12px;
                text-transform: uppercase;
                margin-bottom: 3px;
            }
            
            .info-value {
                color: #333;
                font-size: 14px;
            }
            
            .items-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 10px;
            }
            
            .items-table th,
            .items-table td {
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #ddd;
            }
            
            .items-table th {
                background-color: #d4b896;
                color: white;
                font-weight: bold;
                font-size: 12px;
                text-transform: uppercase;
            }
            
            .items-table td {
                font-size: 14px;
            }
            
            .items-table .text-right {
                text-align: right;
            }
            
            .total-row {
                background-color: #f0f0f0;
                font-weight: bold;
            }
            
            .payment-status {
                display: inline-block;
                padding: 5px 15px;
                border-radius: 20px;
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
            }
            
            .status-lunas {
                background-color: #d4edda;
                color: #155724;
            }
            
            .status-belum-lunas {
                background-color: #fff3cd;
                color: #856404;
            }
            
            .payment-history {
                margin-top: 15px;
            }
            
            .payment-item {
                display: flex;
                justify-content: space-between;
                padding: 8px 0;
                border-bottom: 1px solid #eee;
            }
            
            .footer {
                margin-top: 30px;
                text-align: center;
                color: #666;
                font-size: 12px;
                border-top: 1px solid #eee;
                padding-top: 20px;
            }
            
            .custom-options {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
            }
            
            @media print {
                body {
                    background: white;
                    padding: 0;
                }
                
                .container {
                    box-shadow: none;
                    border-radius: 0;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Header -->
            <div class="header">
                <h1>Detail Pesanan</h1>
                <p>Order #${a.orderNumber}</p>
                <p>Tanggal: ${(0,p.WU)(new Date(a.createdAt),"dd MMMM yyyy")}</p>
            </div>

            <!-- Client Details -->
            <div class="section">
                <h2>Detail Klien & Acara</h2>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Kontak Person</div>
                        <div class="info-value">${a.client.brideName}</div>
                        <div class="info-value">${a.client.primaryPhone}</div>
                        ${a.client.secondaryPhone?`<div class="info-value">${a.client.secondaryPhone}</div>`:""}
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Pengantin Wanita</div>
                        <div class="info-value">${a.client.brideName}</div>
                        <div class="info-value" style="font-size: 12px; color: #666;">${a.client.brideAddress}</div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Pengantin Pria</div>
                        <div class="info-value">${a.client.groomName}</div>
                        <div class="info-value" style="font-size: 12px; color: #666;">${a.client.groomAddress}</div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Orang Tua Pengantin</div>
                        <div class="info-value">Wanita: ${a.client.brideParents||"Belum diisi"}</div>
                        <div class="info-value">Pria: ${a.client.groomParents||"Belum diisi"}</div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Tanggal Akad</div>
                        <div class="info-value">
                            ${a.client.ceremonyDate?(0,p.WU)(new Date(a.client.ceremonyDate),"dd MMMM yyyy"):"-"}
                            ${a.client.ceremonyTime?` - ${a.client.ceremonyTime}`:""}
                            ${a.client.ceremonyEndTime?` s/d ${a.client.ceremonyEndTime}`:""}
                            ${a.client.ceremonyDate?" WIB":""}
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">Tanggal Resepsi</div>
                        <div class="info-value">
                            ${a.client.receptionDate?(0,p.WU)(new Date(a.client.receptionDate),"dd MMMM yyyy"):"-"}
                            ${a.client.receptionTime?` - ${a.client.receptionTime}`:""}
                            ${a.client.receptionEndTime?` s/d ${a.client.receptionEndTime}`:""}
                            ${a.client.receptionDate?" WIB":""}
                        </div>
                    </div>
                </div>
                
                <div class="info-item" style="margin-top: 15px;">
                    <div class="info-label">Lokasi Acara</div>
                    <div class="info-value">${a.eventLocation}</div>
                </div>
            </div>

            <!-- Order Items -->
            <div class="section">
                <h2>Item Pesanan</h2>
                <table class="items-table">
                    <thead>
                        <tr>
                            <th>Item / Paket</th>
                            <th>Jumlah</th>
                            <th class="text-right">Harga</th>
                            <th class="text-right">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${o.map(e=>`
                            <tr>
                                <td>${e.name}</td>
                                <td>${e.quantity}</td>
                                <td class="text-right">${s(e.price)}</td>
                                <td class="text-right">${s(e.total)}</td>
                            </tr>
                        `).join("")}
                        <tr class="total-row">
                            <td colspan="3"><strong>Total</strong></td>
                            <td class="text-right"><strong>${s(a.totalAmount.toString())}</strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Custom Options -->
            <div class="section">
                <h2>Pilihan Kustom</h2>
                <div class="custom-options">
                    ${a.chairModel?`
                        <div class="info-item">
                            <div class="info-label">Kursi Pelaminan</div>
                            <div class="info-value">${a.chairModel}</div>
                        </div>
                    `:""}
                    
                    ${a.softlensColor?`
                        <div class="info-item">
                            <div class="info-label">Warna Tenda</div>
                            <div class="info-value">${a.softlensColor}</div>
                        </div>
                    `:""}
                    
                    ${n.length>0?`
                        <div class="info-item">
                            <div class="info-label">Foto Gaun</div>
                            <div class="info-value">${n.length} Foto</div>
                        </div>
                    `:""}
                </div>
            </div>

            <!-- Payment Status -->
            <div class="section">
                <h2>Status Pembayaran</h2>
                <div class="info-item">
                    <div class="info-label">Status</div>
                    <div class="info-value">
                        <span class="payment-status ${"Lunas"===a.paymentStatus?"status-lunas":"status-belum-lunas"}">
                            ${a.paymentStatus}
                        </span>
                    </div>
                </div>
                
                ${"Belum Lunas"===a.paymentStatus?`
                    <div class="info-item">
                        <div class="info-label">Sisa Pembayaran</div>
                        <div class="info-value">${s(a.remainingAmount.toString())}</div>
                    </div>
                `:""}
                
                ${a.payments.length>0?`
                    <div class="payment-history">
                        <div class="info-label">Riwayat Pembayaran</div>
                        ${a.payments.map(e=>`
                            <div class="payment-item">
                                <div>
                                    <strong>DP${e.paymentNumber}</strong><br>
                                    <small>${(0,p.WU)(new Date(e.paymentDate),"dd MMMM yyyy")}</small>
                                </div>
                                <div><strong>${s(e.amount.toString())}</strong></div>
                            </div>
                        `).join("")}
                    </div>
                `:""}
            </div>

            ${a.specialRequest?`
                <!-- Notes -->
                <div class="section">
                    <h2>Catatan</h2>
                    <div class="info-value" style="white-space: pre-wrap;">${a.specialRequest}</div>
                </div>
            `:""}

            <!-- Footer -->
            <div class="footer">
                <p>Dokumen ini dibuat secara otomatis pada ${(0,p.WU)(new Date,"dd MMMM yyyy 'pukul' HH:mm")} WIB</p>
            </div>
        </div>
    </body>
    </html>
    `,m=await c().launch({headless:!0,args:["--no-sandbox","--disable-setuid-sandbox"]}),v=await m.newPage();await v.setContent(l,{waitUntil:"networkidle0"});let u=await v.pdf({format:"A4",printBackground:!0,margin:{top:"20px",right:"20px",bottom:"20px",left:"20px"}});return await m.close(),new d.NextResponse(new Uint8Array(u),{headers:{"Content-Type":"application/pdf","Content-Disposition":`attachment; filename="Order-${a.orderNumber}.pdf"`}})}catch(e){return console.error("Error generating PDF:",e),d.NextResponse.json({message:"Failed to generate PDF"},{status:500})}}let v=new o.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/orders/[id]/download-pdf/route",pathname:"/api/orders/[id]/download-pdf",filename:"route",bundlePath:"app/api/orders/[id]/download-pdf/route"},resolvedPagePath:"C:\\laragon\\www\\my-app-finalling\\app\\api\\orders\\[id]\\download-pdf\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:u,staticGenerationAsyncStorage:f,serverHooks:g}=v,b="/api/orders/[id]/download-pdf/route";function y(){return(0,s.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:f})}},2331:(e,t,i)=>{i.d(t,{_:()=>o});var a=i(3524);let o=globalThis.prisma??new a.PrismaClient}};var t=require("../../../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[8948,5972,1838],()=>i(9603));module.exports=a})();