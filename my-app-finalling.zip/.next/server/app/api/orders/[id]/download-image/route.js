"use strict";(()=>{var e={};e.id=3359,e.ids=[3359],e.modules={3524:e=>{e.exports=require("@prisma/client")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},8018:e=>{e.exports=require("puppeteer")},2232:(e,t,i)=>{i.r(t),i.d(t,{originalPathname:()=>u,patchFetch:()=>x,requestAsyncStorage:()=>b,routeModule:()=>m,serverHooks:()=>v,staticGenerationAsyncStorage:()=>f});var a={};i.r(a),i.d(a,{GET:()=>g});var o=i(9303),n=i(8716),r=i(670),s=i(7070),d=i(2331),l=i(8018),p=i.n(l),c=i(1838);async function g(e,{params:t}){try{var i;let{id:e}=t,a=await d._.order.findUnique({where:{id:e},include:{client:!0,payments:{orderBy:{paymentNumber:"asc"}}}});if(!a)return s.NextResponse.json({message:"Order not found"},{status:404});let o=(e=>{if(Array.isArray(e))return e;if("string"==typeof e)try{let t=JSON.parse(e);return Array.isArray(t)?t:[]}catch{}return[]})(a.items),n=((i=a.dressPhotos)&&Array.isArray(i)?i.filter(e=>"string"==typeof e):null)||[],r=e=>`Rp ${parseFloat(e.toString()).toLocaleString("id-ID")}`,l=`
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Order Details - ${a.orderNumber}</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Arial', sans-serif;
                line-height: 1.5;
                color: #333;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                padding: 40px;
                min-height: 100vh;
            }
            
            .container {
                max-width: 900px;
                margin: 0 auto;
                background: white;
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                position: relative;
                overflow: hidden;
            }
            
            .container::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 5px;
                background: linear-gradient(90deg, #d4b896, #c4a886, #d4b896);
            }
            
            .header {
                text-align: center;
                margin-bottom: 40px;
                padding-bottom: 30px;
                border-bottom: 3px solid #d4b896;
                position: relative;
            }
            
            .header h1 {
                color: #d4b896;
                font-size: 36px;
                margin-bottom: 15px;
                font-weight: bold;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            }
            
            .header p {
                color: #666;
                font-size: 16px;
                margin-bottom: 5px;
            }
            
            .header .order-number {
                background: #d4b896;
                color: white;
                padding: 8px 20px;
                border-radius: 25px;
                font-weight: bold;
                display: inline-block;
                margin-top: 10px;
            }
            
            .section {
                margin-bottom: 35px;
                padding: 25px;
                border: 2px solid #f0f0f0;
                border-radius: 12px;
                background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%);
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            }
            
            .section h2 {
                color: #d4b896;
                font-size: 22px;
                margin-bottom: 20px;
                border-bottom: 3px solid #d4b896;
                padding-bottom: 8px;
                font-weight: bold;
                position: relative;
            }
            
            .section h2::after {
                content: '';
                position: absolute;
                bottom: -3px;
                left: 0;
                width: 50px;
                height: 3px;
                background: #c4a886;
            }
            
            .info-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }
            
            .info-item {
                margin-bottom: 15px;
                padding: 15px;
                background: #fafbfc;
                border-radius: 8px;
                border-left: 4px solid #d4b896;
            }
            
            .info-label {
                font-weight: bold;
                color: #555;
                font-size: 13px;
                text-transform: uppercase;
                margin-bottom: 5px;
                letter-spacing: 0.5px;
            }
            
            .info-value {
                color: #333;
                font-size: 15px;
                line-height: 1.4;
            }
            
            .items-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            }
            
            .items-table th,
            .items-table td {
                padding: 15px;
                text-align: left;
                border-bottom: 1px solid #eee;
            }
            
            .items-table th {
                background: linear-gradient(135deg, #d4b896 0%, #c4a886 100%);
                color: white;
                font-weight: bold;
                font-size: 13px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .items-table td {
                font-size: 15px;
                background: white;
            }
            
            .items-table tr:nth-child(even) td {
                background: #f8f9fa;
            }
            
            .items-table .text-right {
                text-align: right;
            }
            
            .total-row td {
                background: #e8f4f8 !important;
                font-weight: bold;
                font-size: 16px;
                border-top: 2px solid #d4b896;
            }
            
            .payment-status {
                display: inline-block;
                padding: 8px 20px;
                border-radius: 25px;
                font-size: 14px;
                font-weight: bold;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .status-lunas {
                background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
                color: #155724;
                border: 2px solid #b8dacc;
            }
            
            .status-belum-lunas {
                background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
                color: #856404;
                border: 2px solid #f4d03f;
            }
            
            .payment-history {
                margin-top: 20px;
            }
            
            .payment-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 15px;
                margin-bottom: 8px;
                background: white;
                border-radius: 8px;
                border-left: 4px solid #d4b896;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            }
            
            .payment-item:last-child {
                margin-bottom: 0;
            }
            
            .footer {
                margin-top: 40px;
                text-align: center;
                color: #666;
                font-size: 13px;
                border-top: 2px solid #f0f0f0;
                padding-top: 25px;
                background: #f8f9fa;
                margin-left: -40px;
                margin-right: -40px;
                margin-bottom: -40px;
                padding-left: 40px;
                padding-right: 40px;
                padding-bottom: 25px;
            }
            
            .custom-options {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }
            
            .highlight-box {
                background: linear-gradient(135deg, #fff9e6 0%, #fff3cd 100%);
                border: 2px solid #d4b896;
                border-radius: 10px;
                padding: 20px;
                margin: 15px 0;
            }
            
            .watermark {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 120px;
                color: rgba(212, 184, 150, 0.05);
                font-weight: bold;
                z-index: 0;
                pointer-events: none;
            }
            
            .content {
                position: relative;
                z-index: 1;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="watermark">ORDER</div>
            <div class="content">
                <!-- Header -->
                <div class="header">
                    <h1>Detail Pesanan</h1>
                    <div class="order-number">Order #${a.orderNumber}</div>
                    <p>Tanggal: ${(0,c.WU)(new Date(a.createdAt),"dd MMMM yyyy")}</p>
                </div>

                <!-- Client Details -->
                <div class="section">
                    <h2>Detail Klien & Acara</h2>
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Kontak Person</div>
                            <div class="info-value">
                                <strong>${a.client.brideName}</strong><br>
                                ${a.client.primaryPhone}<br>
                                ${a.client.secondaryPhone||""}
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <div class="info-label">Pengantin Wanita</div>
                            <div class="info-value">
                                <strong>${a.client.brideName}</strong><br>
                                <small style="color: #666;">${a.client.brideAddress}</small>
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <div class="info-label">Pengantin Pria</div>
                            <div class="info-value">
                                <strong>${a.client.groomName}</strong><br>
                                <small style="color: #666;">${a.client.groomAddress}</small>
                            </div>
                        </div>
                        
                        <div class="info-item">
                            <div class="info-label">Orang Tua Pengantin</div>
                            <div class="info-value">
                                <strong>Wanita:</strong> ${a.client.brideParents||"Belum diisi"}<br>
                                <strong>Pria:</strong> ${a.client.groomParents||"Belum diisi"}
                            </div>
                        </div>
                    </div>
                    
                    <div class="highlight-box">
                        <div class="info-grid">
                            <div class="info-item" style="background: transparent; border: none; padding: 10px;">
                                <div class="info-label">Tanggal Akad</div>
                                <div class="info-value">
                                    ${a.client.ceremonyDate?(0,c.WU)(new Date(a.client.ceremonyDate),"dd MMMM yyyy"):"-"}
                                    ${a.client.ceremonyTime?` - ${a.client.ceremonyTime}`:""}
                                    ${a.client.ceremonyEndTime?` s/d ${a.client.ceremonyEndTime}`:""}
                                    ${a.client.ceremonyDate?" WIB":""}
                                </div>
                            </div>
                            
                            <div class="info-item" style="background: transparent; border: none; padding: 10px;">
                                <div class="info-label">Tanggal Resepsi</div>
                                <div class="info-value">
                                    ${a.client.receptionDate?(0,c.WU)(new Date(a.client.receptionDate),"dd MMMM yyyy"):"-"}
                                    ${a.client.receptionTime?` - ${a.client.receptionTime}`:""}
                                    ${a.client.receptionEndTime?` s/d ${a.client.receptionEndTime}`:""}
                                    ${a.client.receptionDate?" WIB":""}
                                </div>
                            </div>
                        </div>
                        
                        <div class="info-item" style="background: transparent; border: none; padding: 10px; margin-top: 10px;">
                            <div class="info-label">Lokasi Acara</div>
                            <div class="info-value"><strong>${a.eventLocation}</strong></div>
                        </div>
                    </div>
                </div>

                <!-- Order Items -->
                <div class="section">
                    <h2>Item Pesanan</h2>
                    <table class="items-table">
                        <thead>
                            <tr>
                                <th>Item / Paket</th>
                                <th>Jumlah</th>
                                <th class="text-right">Harga</th>
                                <th class="text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${o.map(e=>`
                                <tr>
                                    <td><strong>${e.name}</strong></td>
                                    <td>${e.quantity}</td>
                                    <td class="text-right">${r(e.price)}</td>
                                    <td class="text-right"><strong>${r(e.total)}</strong></td>
                                </tr>
                            `).join("")}
                            <tr class="total-row">
                                <td colspan="3"><strong>TOTAL KESELURUHAN</strong></td>
                                <td class="text-right"><strong>${r(a.totalAmount.toString())}</strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Custom Options -->
                <div class="section">
                    <h2>Pilihan Kustom</h2>
                    <div class="custom-options">
                        ${a.chairModel?`
                            <div class="info-item">
                                <div class="info-label">Kursi Pelaminan</div>
                                <div class="info-value">${a.chairModel}</div>
                            </div>
                        `:""}
                        
                        ${a.softlensColor?`
                            <div class="info-item">
                                <div class="info-label">Warna Tenda</div>
                                <div class="info-value">${a.softlensColor}</div>
                            </div>
                        `:""}
                        
                        ${n.length>0?`
                            <div class="info-item">
                                <div class="info-label">Foto Gaun</div>
                                <div class="info-value"><strong>${n.length} Foto</strong> tersedia</div>
                            </div>
                        `:""}
                    </div>
                </div>

                <!-- Payment Status -->
                <div class="section">
                    <h2>Status Pembayaran</h2>
                    <div class="info-item">
                        <div class="info-label">Status Pembayaran</div>
                        <div class="info-value">
                            <span class="payment-status ${"Lunas"===a.paymentStatus?"status-lunas":"status-belum-lunas"}">
                                ${a.paymentStatus}
                            </span>
                        </div>
                    </div>
                    
                    ${"Belum Lunas"===a.paymentStatus?`
                        <div class="info-item">
                            <div class="info-label">Sisa Pembayaran</div>
                            <div class="info-value"><strong style="color: #e74c3c;">${r(a.remainingAmount.toString())}</strong></div>
                        </div>
                    `:""}
                    
                    ${a.payments.length>0?`
                        <div class="payment-history">
                            <div class="info-label" style="margin-bottom: 15px;">Riwayat Pembayaran</div>
                            ${a.payments.map(e=>`
                                <div class="payment-item">
                                    <div>
                                        <strong>DP${e.paymentNumber}</strong><br>
                                        <small style="color: #666;">${(0,c.WU)(new Date(e.paymentDate),"dd MMMM yyyy")}</small>
                                    </div>
                                    <div><strong style="color: #27ae60;">${r(e.amount.toString())}</strong></div>
                                </div>
                            `).join("")}
                        </div>
                    `:""}
                </div>

                ${a.specialRequest?`
                    <!-- Notes -->
                    <div class="section">
                        <h2>Catatan Khusus</h2>
                        <div class="highlight-box">
                            <div class="info-value" style="white-space: pre-wrap; font-style: italic;">${a.specialRequest}</div>
                        </div>
                    </div>
                `:""}

                <!-- Footer -->
                <div class="footer">
                    <p><strong>Dokumen ini dibuat secara otomatis</strong></p>
                    <p>Tanggal: ${(0,c.WU)(new Date,"dd MMMM yyyy 'pukul' HH:mm")} WIB</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    `,g=await p().launch({headless:!0,args:["--no-sandbox","--disable-setuid-sandbox"]}),m=await g.newPage();await m.setViewport({width:1200,height:1600,deviceScaleFactor:2}),await m.setContent(l,{waitUntil:"networkidle0"});let b=await m.screenshot({type:"png",fullPage:!0});return await g.close(),new s.NextResponse(new Uint8Array(b),{headers:{"Content-Type":"image/png","Content-Disposition":`attachment; filename="Order-${a.orderNumber}.png"`}})}catch(e){return console.error("Error generating image:",e),s.NextResponse.json({message:"Failed to generate image"},{status:500})}}let m=new o.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/orders/[id]/download-image/route",pathname:"/api/orders/[id]/download-image",filename:"route",bundlePath:"app/api/orders/[id]/download-image/route"},resolvedPagePath:"C:\\laragon\\www\\my-app-finalling\\app\\api\\orders\\[id]\\download-image\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:b,staticGenerationAsyncStorage:f,serverHooks:v}=m,u="/api/orders/[id]/download-image/route";function x(){return(0,r.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:f})}},2331:(e,t,i)=>{i.d(t,{_:()=>o});var a=i(3524);let o=globalThis.prisma??new a.PrismaClient}};var t=require("../../../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[8948,5972,1838],()=>i(2232));module.exports=a})();