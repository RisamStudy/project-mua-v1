"use strict";(()=>{var e={};e.id=9813,e.ids=[9813],e.modules={2934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},6113:e=>{e.exports=require("crypto")},7147:e=>{e.exports=require("fs")},1017:e=>{e.exports=require("path")},7794:(e,t,a)=>{a.r(t),a.d(t,{originalPathname:()=>A,patchFetch:()=>T,requestAsyncStorage:()=>y,routeModule:()=>w,serverHooks:()=>k,staticGenerationAsyncStorage:()=>$});var i={};a.r(i),a.d(i,{GET:()=>v});var n=a(9303),o=a(8716),r=a(670),s=a(7070),d=a(3493);let l=require("puppeteer");var p=a.n(l);let c=()=>({headless:!0,args:["--no-sandbox","--disable-setuid-sandbox","--disable-dev-shm-usage","--disable-accelerated-2d-canvas","--no-first-run","--no-zygote","--single-process","--disable-gpu"]}),g=async()=>{let e=c();return await p().launch(e)};var m=a(9178),u=a(7147),b=a.n(u),x=a(1017),f=a.n(x);async function h(){try{let e;let t=f().join(process.cwd(),"public","logo.png"),a=f().join(process.cwd(),"public","logo1.png");if(b().existsSync(t))e=b().readFileSync(t);else if(b().existsSync(a))e=b().readFileSync(a);else{let e=`<svg width="80" height="80" xmlns="http://www.w3.org/2000/svg">
        <circle cx="40" cy="40" r="35" fill="#d4b896"/>
        <text x="40" y="50" text-anchor="middle" fill="white" font-family="Arial" font-size="20" font-weight="bold">RORO</text>
      </svg>`;return`data:image/svg+xml;base64,${Buffer.from(e).toString("base64")}`}return e.toString("base64")}catch(t){console.error("Error loading logo:",t);let e=`<svg width="80" height="80" xmlns="http://www.w3.org/2000/svg">
      <circle cx="40" cy="40" r="35" fill="#d4b896"/>
      <text x="40" y="50" text-anchor="middle" fill="white" font-family="Arial" font-size="20" font-weight="bold">RORO</text>
    </svg>`;return`data:image/svg+xml;base64,${Buffer.from(e).toString("base64")}`}}async function v(e,{params:t}){try{await (0,m.KN)();let{id:e}=t,a=await d._.invoice.findUnique({where:{id:e},include:{order:{include:{client:!0,payments:{orderBy:{paymentNumber:"asc"}}}},payment:!0}});if(!a)return s.NextResponse.json({message:"Invoice not found"},{status:404});let i=(e=>{if(Array.isArray(e))return e;if("string"==typeof e)try{let t=JSON.parse(e);return Array.isArray(t)?t:[]}catch{}return[]})(a.order.items),n=a.order?.payments||[],o=e=>`Rp ${parseFloat(e.toString()).toLocaleString("id-ID")}`,r=e=>("string"==typeof e?new Date(e):e).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}),l=i.reduce((e,t)=>e+parseFloat(t.total?.toString()||"0"),0),p=n.reduce((e,t)=>e+parseFloat(t.amount),0),c=l-p,u=await h(),b=`
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Invoice ${a.invoiceNumber}</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: 'Arial', sans-serif; 
                line-height: 1.5; 
                color: #333; 
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                padding: 40px;
                min-height: 100vh;
            }
            .container { 
                max-width: 900px; 
                margin: 0 auto; 
                background: white;
                border-radius: 15px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
                position: relative;
            }
            .container::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 5px;
                background: linear-gradient(90deg, #d4b896, #c4a886, #d4b896);
            }
            .header { 
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 40px;
                padding: 40px 40px 30px 40px;
                border-bottom: 3px solid #d4b896;
                background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            }
            .logo-section {
                display: flex;
                align-items: center;
                gap: 20px;
            }
            .logo {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 5px 15px rgba(212, 184, 150, 0.3);
                overflow: hidden;
                background: white;
                border: 3px solid #d4b896;
            }
            .logo img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }
            .invoice-title {
                font-size: 36px;
                font-weight: bold;
                color: #d4b896;
                margin-bottom: 5px;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            }
            .invoice-number {
                font-size: 16px;
                color: #666;
                background: #d4b896;
                color: white;
                padding: 5px 15px;
                border-radius: 20px;
                font-weight: bold;
            }
            .company-info {
                text-align: right;
            }
            .company-name {
                font-size: 20px;
                font-weight: bold;
                margin-bottom: 8px;
                color: #d4b896;
            }
            .company-address {
                font-size: 13px;
                color: #666;
                line-height: 1.6;
            }
            .bill-to-section {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 40px;
                margin-bottom: 40px;
                padding: 0 40px 30px 40px;
                border-bottom: 2px solid #d4b896;
            }
            .section-title {
                font-size: 13px;
                font-weight: bold;
                color: #d4b896;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 15px;
                border-bottom: 2px solid #d4b896;
                padding-bottom: 5px;
            }
            .client-name {
                font-size: 18px;
                font-weight: bold;
                margin-bottom: 8px;
                color: #333;
            }
            .client-details {
                font-size: 13px;
                color: #666;
                line-height: 1.6;
            }
            .payment-details {
                text-align: right;
            }
            .detail-row {
                display: flex;
                justify-content: space-between;
                margin-bottom: 8px;
                font-size: 13px;
            }
            .detail-label {
                color: #666;
            }
            .detail-value {
                font-weight: bold;
                color: #333;
            }
            .items-section {
                padding: 0 40px;
                margin-bottom: 30px;
            }
            .items-table {
                width: 100%;
                border-collapse: collapse;
                border-radius: 10px;
                overflow: hidden;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            .items-table th {
                background: linear-gradient(135deg, #d4b896, #c4a886);
                color: white;
                padding: 18px;
                text-align: left;
                font-size: 13px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                font-weight: bold;
            }
            .items-table td {
                padding: 18px;
                border-bottom: 1px solid #eee;
                font-size: 15px;
                background: white;
            }
            .items-table tr:nth-child(even) td {
                background: #f8f9fa;
            }
            .text-right { text-align: right; }
            .text-center { text-align: center; }
            .totals-section {
                display: flex;
                justify-content: flex-end;
                margin-bottom: 40px;
                padding: 0 40px;
            }
            .totals-table {
                width: 450px;
            }
            .total-row {
                display: flex;
                justify-content: space-between;
                padding: 12px 0;
                font-size: 15px;
            }
            .total-row.subtotal {
                border-bottom: 1px solid #eee;
                color: #666;
            }
            .total-row.grand-total {
                font-weight: bold;
                font-size: 18px;
                border-top: 3px solid #d4b896;
                padding-top: 15px;
                color: #333;
            }
            .total-row.paid {
                background: linear-gradient(135d, #d4edda, #c3e6cb);
                padding: 15px;
                border-radius: 8px;
                color: #155724;
                font-weight: bold;
                margin: 10px 0;
                border: 2px solid #b8dacc;
            }
            .total-row.remaining {
                background: linear-gradient(135deg, #fff3cd, #ffeaa7);
                padding: 15px;
                border-radius: 8px;
                color: #856404;
                font-weight: bold;
                border: 2px solid #d4b896;
                margin: 10px 0;
            }
            .notes-section {
                margin-top: 40px;
                padding: 30px 40px 40px 40px;
                border-top: 2px solid #d4b896;
                background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            }
            .notes-title {
                font-size: 13px;
                font-weight: bold;
                color: #d4b896;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 15px;
                border-bottom: 2px solid #d4b896;
                padding-bottom: 5px;
            }
            .notes-content {
                font-size: 13px;
                color: #666;
                line-height: 1.8;
            }
            .notes-item {
                margin-bottom: 12px;
                padding: 10px;
                background: white;
                border-radius: 5px;
                border-left: 4px solid #d4b896;
            }
            .watermark {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 120px;
                color: rgba(212, 184, 150, 0.05);
                font-weight: bold;
                z-index: 0;
                pointer-events: none;
            }
            .content {
                position: relative;
                z-index: 1;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="watermark">INVOICE</div>
            <div class="content">
                <!-- Header -->
                <div class="header">
                    <div class="logo-section">
                        <div class="logo">
                            <img src="${u.startsWith("data:")?u:`data:image/png;base64,${u}`}" alt="RORO MUA Logo" />
                        </div>
                        <div>
                            <div class="invoice-title">FAKTUR</div>
                            <div class="invoice-number">#${a.invoiceNumber}</div>
                        </div>
                    </div>
                    <div class="company-info">
                        <div class="company-name">RORO MUA</div>
                        <div class="company-address">
                            Perumahan Kaliwulu blok AC no.1<br>
                            Kec.Plered Kab Cirebon<br>
                            (Depan Lapangan)
                        </div>
                    </div>
                </div>

                <!-- Bill To Section -->
                <div class="bill-to-section">
                    <div>
                        <div class="section-title">Diterbitkan Kepada</div>
                        <div class="client-name">${a.order.client.brideName}</div>
                        <div class="client-details">
                            ${a.order.client.brideAddress}<br>
                            <strong>HP Pengantin Wanita:</strong> ${a.order.client.primaryPhone}
                            ${a.order.client.secondaryPhone?`<br><strong>HP Pengantin Pria:</strong> ${a.order.client.secondaryPhone}`:""}
                        </div>
                    </div>
                    <div class="payment-details">
                        <div class="section-title">Detail Pembayaran</div>
                        <div class="detail-row">
                            <span class="detail-label">Tanggal Terbit:</span>
                            <span class="detail-value">${r(a.issueDate)}</span>
                        </div>
                        ${a.dueDate?`
                        <div class="detail-row">
                            <span class="detail-label">Jatuh Tempo:</span>
                            <span class="detail-value">${r(a.dueDate)}</span>
                        </div>
                        `:""}
                        <div class="detail-row">
                            <span class="detail-label">ID Pesanan:</span>
                            <span class="detail-value">${a.order.orderNumber}</span>
                        </div>
                    </div>
                </div>

                <!-- Items Table -->
                <div class="items-section">
                    <table class="items-table">
                        <thead>
                            <tr>
                                <th>Layanan</th>
                                <th class="text-center">QTY</th>
                                <th class="text-right">Harga</th>
                                <th class="text-right">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${i.map(e=>`
                                <tr>
                                    <td><strong>${e.name}</strong></td>
                                    <td class="text-center">${e.quantity}</td>
                                    <td class="text-right">${o(e.price)}</td>
                                    <td class="text-right"><strong>${o(e.total)}</strong></td>
                                </tr>
                            `).join("")}
                        </tbody>
                    </table>
                </div>

                <!-- Totals Section -->
                <div class="totals-section">
                    <div class="totals-table">
                        <div class="total-row subtotal">
                            <span>Subtotal</span>
                            <span>${o(l)}</span>
                        </div>
                        
                        ${n.map(e=>`
                            <div class="total-row">
                                <span>DP${e.paymentNumber}</span>
                                <span>${o(e.amount)}</span>
                            </div>
                        `).join("")}
                        
                        <div class="total-row grand-total">
                            <span>JUMLAH TOTAL</span>
                            <span>${o(l)}</span>
                        </div>
                        
                        <div class="total-row paid">
                            <span>Total Dibayar</span>
                            <span>${o(p)}</span>
                        </div>
                        
                        <div class="total-row remaining">
                            <span>Sisa Tagihan</span>
                            <span>${o(c)}</span>
                        </div>
                    </div>
                </div>

                <!-- Notes Section -->
                <div class="notes-section">
                    <div class="notes-title">Catatan / Keterangan</div>
                    <div class="notes-content">
                        ${a.payment?`
                            <div class="notes-item">
                                <strong>Invoice untuk pembayaran DP${a.payment.paymentNumber} - ${a.order.orderNumber}</strong><br>
                                <strong>Metode Pembayaran:</strong> ${a.payment.paymentMethod||"Transfer Bank"}
                            </div>
                        `:""}
                        
                        ${a.payment?.notes?`
                            <div class="notes-item">
                                <strong>Catatan pembayaran:</strong> ${a.payment.notes}
                            </div>
                        `:""}
                        
                        ${a.notes?`
                            <div class="notes-item">
                                ${a.notes}
                            </div>
                        `:""}
                        
                        ${a.notes||a.payment?.notes?"":`
                            <div class="notes-item">
                                Terima kasih telah memilih Roro MUA untuk hari istimewa Anda! Kami sangat menghargai kepercayaan Anda.
                            </div>
                        `}
                    </div>
                </div>
                
                <!-- Footer with Bank Information -->
                <div style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #d4b896; text-align: center; font-size: 12px; color: #666;">
                    <p style="margin-bottom: 15px;"><strong>Informasi Rekening Bank</strong></p>
                    <div style="display: flex; justify-content: center; gap: 30px; flex-wrap: wrap;">
                        <div>
                            <strong>BCA:</strong> 774 559 3402<br>
                            <small>A/N FATIMATUZ ZAHRO</small>
                        </div>
                        <div>
                            <strong>BRI:</strong> 0601 01000 547 563<br>
                            <small>A/N FATIMA TUZZAHRO</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    `,x=await g(),f=await x.newPage();await f.setViewport({width:1200,height:1600,deviceScaleFactor:2}),await f.setContent(b,{waitUntil:"networkidle0"});let v=await f.screenshot({type:"png",fullPage:!0});await x.close();let w=Buffer.from(v);return new Response(w,{headers:{"Content-Type":"image/png","Content-Disposition":`attachment; filename="Invoice-${a.invoiceNumber}.png"`}})}catch(e){return console.error("Error generating image:",e),s.NextResponse.json({message:"Failed to generate image"},{status:500})}}let w=new n.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/invoices/[id]/download-image/route",pathname:"/api/invoices/[id]/download-image",filename:"route",bundlePath:"app/api/invoices/[id]/download-image/route"},resolvedPagePath:"C:\\laragon\\www\\my-app-finalling\\app\\api\\invoices\\[id]\\download-image\\route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:y,staticGenerationAsyncStorage:$,serverHooks:k}=w,A="/api/invoices/[id]/download-image/route";function T(){return(0,r.patchFetch)({serverHooks:k,staticGenerationAsyncStorage:$})}},9178:(e,t,a)=>{a.d(t,{KN:()=>m,PR:()=>g,RA:()=>c,pH:()=>p});var i=a(1615);a(8585);var n=a(3493),o=a(8691),r=a(6113),s=a.n(r);if(!process.env.JWT_SECRET)throw Error("JWT_SECRET environment variable is required");let d=process.env.JWT_SECRET;async function l(e,t){return o.ZP.compare(e,t)}async function p(e,t){try{let a=e.trim().toLowerCase(),i=await n._.user.findFirst({where:{OR:[{username:a},{email:a}],isActive:!0}});if(!i)return await o.ZP.hash(t,12),null;if(!await l(t,i.password))return null;return{id:i.id,username:i.username,email:i.email,name:i.name,role:i.role}}catch(e){return console.error("Login error:",e),null}}function c(e){let t=JSON.stringify({id:e.id,username:e.username,email:e.email,name:e.name,role:e.role,timestamp:Date.now(),nonce:s().randomBytes(16).toString("hex")}),a=Buffer.from(t).toString("base64"),i=s().createHmac("sha256",d).update(a).digest("base64");return`${a}.${i}`}async function g(){try{let e=(await (0,i.cookies)()).get("auth_token");if(!e)return null;return function(e){try{let[t,a]=e.split(".");if(!t||!a)return null;let i=s().createHmac("sha256",d).update(t).digest("base64");if(!s().timingSafeEqual(Buffer.from(a),Buffer.from(i)))return null;let n=Buffer.from(t,"base64").toString("utf-8"),o=JSON.parse(n);if(Date.now()-o.timestamp>864e5)return null;return{id:o.id,username:o.username,email:o.email,name:o.name,role:o.role}}catch(e){return console.error("Token parse error:",e),null}}(e.value)}catch(e){return console.error("Get user error:",e),null}}async function m(){let e=await g();if(!e)throw Error("Unauthorized");return e}},3493:(e,t,a)=>{a.d(t,{_:()=>n});let i=require("@prisma/client"),n=globalThis.prisma??new i.PrismaClient}};var t=require("../../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),i=t.X(0,[8948,5972,5766],()=>a(7794));module.exports=i})();